package com.zefari.modules;

import com.zefari.module.Category;
import com.zefari.module.Module;
import com.zefari.setting.Setting;
import com.zefari.util.Fx;
import com.zefari.util.TpsTracker;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class HudModule extends Module {
    public final Setting.Bool watermark = add(new Setting.Bool("Watermark", true));
    public final Setting.Bool fps = add(new Setting.Bool("FPS", true));
    public final Setting.Bool server = add(new Setting.Bool("Server IP", true));
    public final Setting.Bool player = add(new Setting.Bool("Player Name", true));
    public final Setting.Bool tps = add(new Setting.Bool("TPS", true));

    public HudModule() { super("HUD", Category.CLIENT); }

    @Override
    public void onHudRender(DrawContext ctx) {
        if (mc.options.hudHidden || mc.player == null) return;
        TextRenderer tr = mc.textRenderer;
        int x = 6, y = 6;

        if (watermark.value) {
            String t = "Zefari";
            int w = tr.getWidth(t) + 18;
            ctx.fill(x, y, x + w, y + 16, 0xB0101018);
            Fx.sweep(ctx, x, y, w, 1, 255);
            Fx.sweep(ctx, x, y + 15, w, 1, 255);
            Fx.glow(ctx, x, y, w, 16);
            Fx.waveText(ctx, tr, t, x + 9, y + 4);
            y += 23;
        }

        List<String[]> rows = new ArrayList<>();
        if (fps.value) rows.add(new String[]{"FPS", String.valueOf(mc.getCurrentFps())});
        if (server.value) {
            String addr = mc.getCurrentServerEntry() != null ? mc.getCurrentServerEntry().address
                    : (mc.isInSingleplayer() ? "Singleplayer" : "-");
            rows.add(new String[]{"Server", addr});
        }
        if (player.value) rows.add(new String[]{"Player", mc.getSession().getUsername()});
        if (tps.value) rows.add(new String[]{"TPS", String.format(Locale.ROOT, "%.1f", TpsTracker.get())});
        if (rows.isEmpty()) return;

        int w = 0;
        for (String[] r : rows) w = Math.max(w, tr.getWidth(r[0] + ": " + r[1]));
        w += 12;
        int h = rows.size() * 11 + 4;
        double t = Fx.time() * 2.0;

        ctx.fill(x, y, x + w, y + h, 0xB0101018);
        ctx.fillGradient(x, y, x + 2, y + h, Fx.wave(t, 255), Fx.wave(t + 1.6, 255));
        Fx.glow(ctx, x, y, w, h);
        int ty = y + 3;
        int i = 0;
        for (String[] r : rows) {
            int cx = x + 6;
            ctx.drawText(tr, r[0] + ": ", cx, ty, Fx.wave(t - i * 0.6, 255), true);
            ctx.drawText(tr, r[1], cx + tr.getWidth(r[0] + ": "), ty, 0xFFFFFFFF, true);
            ty += 11;
            i++;
        }
    }
}
