package com.zefari.util;

import com.zefari.module.ModuleManager;
import com.zefari.modules.ClickGuiModule;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.MathHelper;

/** Hafif "shader" efektleri: animasyonlu gradyan, isik taramasi, glow. Gercek GLSL kullanmaz, oyunu cokertmez. */
public final class Fx {
    public static double time() { return System.nanoTime() / 1.0e9; }

    /** ClickGui'de secilen ana renk (RGB). */
    public static int theme() {
        ClickGuiModule g = ModuleManager.clickGui;
        return MathHelper.hsvToRgb((float) g.hue.value, (float) g.sat.value, (float) g.bri.value) & 0xFFFFFF;
    }

    public static int alpha(int rgb, int a) { return ((a & 255) << 24) | (rgb & 0xFFFFFF); }

    /** Ana renk etrafinda dalgalanan renk. */
    public static int wave(double phase, int a) {
        ClickGuiModule g = ModuleManager.clickGui;
        float h = (float) (g.hue.value + Math.sin(phase) * 0.04);
        h -= (float) Math.floor(h);
        float v = (float) (g.bri.value * (0.72 + 0.28 * Math.sin(phase * 1.7 + 1)));
        v = MathHelper.clamp(v, 0f, 1f);
        return alpha(MathHelper.hsvToRgb(h, (float) g.sat.value, v), a);
    }

    /** Soldan saga akan isikli bar. */
    public static void sweep(DrawContext c, int x, int y, int w, int h, int a) {
        double t = time() * 2.2;
        for (int i = 0; i < w; i += 3) {
            c.fill(x + i, y, Math.min(x + i + 3, x + w), y + h, wave(t - i * 0.045, a));
        }
    }

    /** Kutunun etrafinda yumusak parlama. */
    public static void glow(DrawContext c, int x, int y, int w, int h) {
        double t = time() * 2.0;
        for (int i = 1; i <= 3; i++) {
            c.drawBorder(x - i, y - i, w + 2 * i, h + 2 * i, wave(t + i * 0.3, 70 / i));
        }
    }

    /** Harf harf dalgalanan renkli yazi. Bitis x'ini dondurur. */
    public static int waveText(DrawContext c, TextRenderer tr, String s, int x, int y) {
        double t = time() * 2.4;
        int cx = x;
        for (int i = 0; i < s.length(); i++) {
            String ch = String.valueOf(s.charAt(i));
            c.drawText(tr, ch, cx, y, wave(t - i * 0.35, 255), true);
            cx += tr.getWidth(ch);
        }
        return cx;
    }
}
