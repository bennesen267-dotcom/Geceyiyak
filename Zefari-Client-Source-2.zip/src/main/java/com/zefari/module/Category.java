package com.zefari.module;

public enum Category {
    COMBAT("Combat"), RENDER("Render"), MOVEMENT("Movement"), MISC("Misc"), CLIENT("Client");
    public final String label;
    Category(String label) { this.label = label; }
}
